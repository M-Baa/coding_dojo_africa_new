import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>

    <h1> Hello Dojo</h1>
    <h3>Things I need to do </h3>
    <p>* Learn React </p>
    <p>* Climb Mt. Everest</p>
    <p>* Feed the dogs</p>
  
    </div>
    
  );
}

export default App;
